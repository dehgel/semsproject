
<?php include('header.php');?>

<!-- Register account -->
<div id="registrationModal" class="modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Registration Form</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="registrationForm" class="modal-body" enctype="multipart/form-data">
                <div class="form-group">
                  <label for="randid">ID Number:</label>
                  <input type="text" id="randid" name="randid" value="" class="form-control">
                </div>
                <div class="form-group">
                    <label for="privileges">Account Type:</label>
                    <select id="privileges" name="privileges" class="form-control">
                        <option value="1">Administrator</option>
                        <option value="2">Consumer</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="passw">Login Password:</label>
                    <input type="password" id="passw" name="passw" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="firstname">First Name:</label>
                    <input type="text" id="firstname" name="firstname" class="form-control" required>
                    <label for="middlename">Middle Name:</label>
                    <input type="text" id="middlename" name="middlename" class="form-control" required>
                    <label for="lastname">Last Name:</label>
                    <input type="text" id="lastname" name="lastname" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" class="form-control" required>
                </div>

                <div class="form-check">
                    <input type="checkbox" id="additionalInfoCheckbox" class="form-check-input">
                    <label class="form-check-label" for="additionalInfoCheckbox">Open Additional Information</label>
                </div>

                <div id="additionalInfo" style="display: none;">
                    <input type="text" id="course" name="course" class="form-control" placeholder="Course">
                    <input type="text" id="mobile" name="mobile" class="form-control" placeholder="Mobile">
                    <input type="text" id="socialNetwork" name="socialNetwork" class="form-control" placeholder="Social Network">
                </div>
                <div class="form-group">
                    <label for="profileImage">Profile Picture:</label>
                    <input type="file" id="profileImage" name="profileImage" class="form-control-file" onchange="previewImage()">
                    <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 100%; margin-top: 10px;">
                </div>
                <div id="preloader" class="hidden">
                    <img src="dist/img/preloader.gif" alt="Loading...">
                </div>
                <button type="submit" class="btn btn-secondary">Register</button>
            </form>
        </div>
    </div>
</div>
<script>
    function previewImage() {
        const fileInput = document.getElementById('profileImage');
        const imagePreview = document.getElementById('imagePreview');
        
        if (fileInput.files && fileInput.files[0]) {
            const reader = new FileReader();

            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            };

            reader.readAsDataURL(fileInput.files[0]);
        }
    }
    
</script>
<!-- ./Register -->
<!-- pay bills -->
<div id="payBillsModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="payBillsModalLabel">Pay Bills</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form to enter CONSUMER_ID and AMOUNT -->
                <form id="paymentForm">
                    <div class="mb-3">
                        <label for="consumerIdInput" class="form-label">CONSUMER_ID</label>
                        <input type="text" class="form-control" id="consumerIdInput" name="CONSUMER_ID" required="">
                    </div>
                    <div class="mb-3">
                        <label for="amountInput" class="form-label">AMOUNT</label>
                        <input type="text" class="form-control" id="amountInput" name="AMOUNT" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-secondary" id="submitPayment">Submit</button>
            </div>
        </div>
    </div>
</div>

<!-- ./paybills -->
<!-- Edit Modal -->
<div id="editModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Edit User Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span type="button" class="close" data-dismiss="modal">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="editForm">
          <input type="hidden" id="user_id" name="user_id" value="">
          <div class="form-group">
            <label for="editUsername">Username:</label>
            <input type="text" class="form-control" id="editUsername" name="editUsername" required>
          </div>
          <div class="form-group">
            <label for="editRole">Role:</label>
            <select class="form-control" id="editRole" name="editRole" onchange="toggleEditOptionalFields()">
              <option value="1">Administrator</option>
              <option value="2">Consumer</option>
            </select>
          </div>
          <div class="form-group">
            <label for="editEmail">Email:</label>
            <input type="email" class="form-control" id="editEmail" name="editEmail" required>
          </div>
          <div class="form-group">
            <label for="editFirstName">First Name:</label>
            <input type="text" class="form-control" id="editFirstName" name="editFirstName" required>
          </div>
          <div class="form-group">
            <label for="editMiddleName">Middle Name:</label>
            <input type="text" class="form-control" id="editMiddleName" name="editMiddleName">
          </div>
          <div class="form-group">
            <label for="editFamilyName">Family Name:</label>
            <input type="text" class="form-control" id="editFamilyName" name="editFamilyName" required>
          </div>
          <div class="form-group">
            <label for="editAddress">Address:</label>
            <textarea class="form-control" id="editAddress" name="editAddress" required></textarea>
          </div>
          
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary modal-close" data-dismiss="modal">Close</button>
        <button id="editFormSubmit" type="button" class="btn btn-secondary">Save Changes</button>
      </div>
    </div>
  </div>
</div>

<!-- OTA Update Modal -->
<div id="otaFormPopup" class="modal" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">OTA Update</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form id="otaForm" enctype="multipart/form-data">
            <div class="form-group">
                <label for="firmwareFile">Firmware File:</label>
                <input type="file" class="form-control-file" id="firmwareFile" name="file" accept=".bin, .ino" required>
                <div class="progress mt-2">
                    <div id="progressBar" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
            <button type="button" class="btn btn-primary" id="uploadBtn">Upload</button>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- ./Edit form -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>

    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
    
      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Deh Saaduddin
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can... 099900012345 -_^</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <div>
        <button id="editButton" class="btn btn-secondary">Settings</button> 
      </div>
    </ul>
  </nav>
  <!-- /.navbar -->
  


  <!-- Main Sidebar Container -->
  <?php require_once('sidebar.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div  class="content-header">
      <div class="container-fluid">
        <div class="row mb-12">
          <div class="col-sm-12">
            <h1 class="m-0">Consumers</h1>
          </div><!-- /.col -->
          <!-- New Account button-->
          <div class="col-sm-12">
            <div id="breadcrumbTitle"></div> 
          </div>
          <!-- /.end new account button -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-secondary">
              <div class="card-header">
                <h3 class="card-title">SEMS User Manager</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <form>
                  <div class="mb-3">
                    <label for="userRole" class="form-label">Select User Role:</label>
                    <select id="userRole" class="form-control">
                        <option value="">All Users</option>
                        <option value="administrator">Administrators</option>
                        <option value="consumer">Consumers</option>
                    </select>
                  </div>
                </form>
                <table id="consumersTable" class="display">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>FULL NAME</th>
                      <th>KWH USED</th>
                      <th>BALANCE</th>
                      <th>ADDRESS</th>
                      <th>STATUS</th>
                      <th style="display:none;">ROLE</th>
                    </tr>
                  </thead>
                  <tbody>
                  <!-- Data will be populated here -->
                  </tbody>
                </table>
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col-md-12 -->

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
<?php include('footer.php');?>
