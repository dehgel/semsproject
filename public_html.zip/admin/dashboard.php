<?php include('header.php');?>

<div class="wrapper">
  <!-- Edit Settings -->
<div id="editSettings" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Settings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="editSettingsForm">
                <div class="mb-3">
                    <label for="ratekwh" class="form-label">Update Rate/KWH</label>
                    <input type="text" class="form-control" id="ratekwh" name="ratekwh" required>
                </div>
                <div class="mb-3">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-secondary" id="submitSettings">Save Changes</button>
                </div>
            </form>
            </div>
            <div class="modal-footer">

            </div>
        </div>
    </div>
</div>
<!-- /. Edit Settings -->
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Deh Saaduddin
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can... 099900012345 -_^</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <div class="col-sm-12">
        <button id="editButton" class="btn btn-secondary">Settings</button> 
      </div>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('sidebar.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">My Account</h1>
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
    <div class="row">
        <div class="col-lg-3 d-flex align-items-center justify-content-center">
            <div class="text-center">
                <!-- Profile Picture -->
                <img id="UserProfilePic" src="" alt="Profile Picture" class="img-fluid rounded-circle" style="max-width: 100%; height: auto; object-fit: cover;">
            </div>
        </div>
        <div class="col-lg-9">
            <div class="card card-secondary">
                <div class="card-header">
                    <h3 class="card-title">Information</h3>
                </div>
                <div class="card-body">
                   
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>Account ID:</td>
                                <td><span id="adminid" class="text-bold"></span></td>
                                <td>Email:</td>
                                <td><span id="adminmail" class="text-bold"></span></td>
                            </tr>
                            <tr>
                                <td>Name:</td>
                                <td><span id="adminname" class="text-bold"></span></td>
                                <td>Mobile:</td>
                                <td><span id="adminmobile" class="text-bold"></span></td>
                            </tr>
                            <tr>
                                <td>Course:</td>
                                <td><span id="admincourse" class="text-bold"></span></td>
                                <td>Social Network:</td>
                                <td><span id="adminsoc" class="text-bold"></span></td>
                            </tr>
                            <tr>
                                <td>Address:</td>
                                <td><span id="adminadd" class="text-bold"></span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Send Message 
        <div class="col-lg-12">
            <div class="card card-secondary">
                <div class="card-header ">
                    <h3 class="card-title">Notify a consumer</h3>
                </div>
                <div class="card-body">
                    <form id="msgtosend">
                        <div class="form-group">
                            <label for="recipient">Recipient</label>
                            <select class="form-control" id="recipient" name="recipient">
   
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="4"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                </div>
            </div>
        </div>-->
    </div>
</div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
<?php include('footer.php');?>
<!-- ./wrapper -->

