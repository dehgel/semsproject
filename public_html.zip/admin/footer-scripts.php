<script>

function previewImage() {
    const fileInput = document.getElementById('profileImage');
    const imagePreview = document.getElementById('imagePreview');
    if (fileInput.files && fileInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block';
        };
        reader.readAsDataURL(fileInput.files[0]);
    }
}
$(document).ready(function(){

    $('#editModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); 
        var id = button.data('id');
        
        var modal = $(this);
        modal.find('.modal-title').text("Update ID: " + id);
        modal.find('#user_id').val(id);
    });

    $('#settingsTabs a').on('click', function (e) {
        e.preventDefault();
        $(this).tab('show');
        $('#editSettingsForm').css('display','block');
    });


    $(document).on('click', '#otaBtn', function() {
        $("#otaFormPopup").modal('show');
    });
    
    
    
      $('#editButton').click(function() {
          $('#editSettings').modal('show');
      });

      $('.updateBtns').on('click', function() {
          var id = $(this).data('id'); 
          $('#editModal').modal('show');
          $('.modal-title').text("Update ID: " + id);
          $('#user_id').val(id);
      });

      // When the user clicks on the username link
      $("i#editIcon").click(function() {
        var user_id = $(this).data('id');
        $('#profileid').val(user_id);
        var profilePicSrc = $("#profilePic").attr("src");
        $("#existprofpics").attr("src", profilePicSrc);
        $("#UserProfilePic").attr("src", profilePicSrc);
        $("#editProfilePic").modal('show');
      });

      // Prevent clicks on the modal content from closing the modal
      $(".modal-content").click(function(event) {
          event.stopPropagation();
      });

      // When the user clicks on the profile image
      $("#existprofpics").click(function() {
          // Trigger a click event on the file input
          $("#fileInput").click();
      });
      // When the user clicks on the profile image
      $("#UserProfilePic").click(function() {
          // Trigger a click event on the file input
          $("#fileInput").click();
      });

      var progressBar = $("#progressBar");

      $("#fileInput").change(function() {

          var selectedFile = this.files[0];

          if (selectedFile) {

              // Display the selected file in the img element
              var reader = new FileReader();
              reader.onload = function(e) {
              $("#existprofpics").attr("src", e.target.result);
              $("#UserProfilePic").attr("src", e.target.result);
              $("#profilePic").attr("src", e.target.result);
              var dataid = $("#adminusername").data("id");
              $('#profileid').val(dataid);

              // Send an AJAX request to the PHP URL
              var formData = new FormData();
              formData.append('profileImage', selectedFile);

              $.ajax({
                  url: '/admin/api/editProfilePicture.php',
                  type: 'POST',
                  data: formData,
                  processData: false,
                  contentType: false,
                  dataType: "json",
                  success: function(response) {
                    Swal.fire({
                    icon: 'success',
                    title: 'Picture updated!',
                    text: response.message,
                    confirmButtonText: 'OK',
                    });
                    $('#editProfilePic').modal('hide');
                  },
                  error: function(jqXHR, textStatus, errorThrown) {
                  // Handle AJAX error
                  console.error("AJAX Error: " + textStatus, errorThrown);
                  }
              });
              };
              reader.readAsDataURL(selectedFile);
          }
      });
        $('.btn-close').on('click', function(e){
            e.preventDefault();
            $('.modal').modal('hide');
        });
        // Handle form submission
        $('#editAboutSettings').on('submit', function (event) {
            event.preventDefault(); // Prevent the default form submission

            // Get form data
            const formData = {
                objectives: $('#objectives').val(),
                mission: $('#mission').val(),
                vision: $('#vision').val(),
            };

            // Send an AJAX POST request to update the database
            $.ajax({
                type: 'POST',
                url: 'api/updateSitesettings.php', 
                data: JSON.stringify(formData), 
                contentType: 'application/json',
                success: function (response) {
                    // Handle success
                    if (response.status === 'success') {
                        // Show a success notification using SweetAlert
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                        });
                    } else {
                        // Show an error notification using SweetAlert
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message,
                        });
                    }
                },
                error: function (error) {
                    // Handle errors
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error updating data.',
                    });
                    console.error('Error updating data:', error);
                },
            });
        });
        
        

    // Define the URL for the API endpoint
    const aboutAPIs = '../api/aboutcontents.php';
        
    // Make an AJAX GET request to the API
    $.ajax({
      url: aboutAPIs,
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        // Extract data fields
        const mission = data['MISSION'];
        const vision = data['VISION'];
        const objective = data['OBJECTIVE'];
        $("#mission").val(mission);
        $("#vision").val(vision);
        $("#objectives").val(objective);
      },
      error: function (error) {
        // Handle errors
        console.error('Error:', error);
      }
    });
    
    // Upload OTA
    $('#uploadBtn').click(function() {
        var formData = new FormData($('#otaForm')[0]);
        
        $.ajax({
            url: 'api/ota_to.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = (evt.loaded / evt.total) * 100;
                        $('#progressBar').css('width', percentComplete + '%').attr('aria-valuenow', percentComplete);
                    }
                }, false);
                return xhr;
            },
            success: function(response) {

                console.log(response);
                Swal.fire({
                    icon: 'success',
                    title: 'Firmware Updated!',
                    text: 'System upgrade will be automatically downloaded to SEM devices'
                });
            },
            error: function(xhr, status, error) {

                console.error(error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Error uploading file.'
                });
            }
        });
    });

    

    $('#updateBtn').click(function() {
        // update
    });


});
    
  </script>
