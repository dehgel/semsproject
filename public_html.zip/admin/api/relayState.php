<?php

/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Content-Type: application/json');
header('Expires: 0');
session_start();

require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();;

$getid = $_GET['esp_id']; 


$id = filter_var($getid, FILTER_SANITIZE_NUMBER_INT);
$check_query = "SELECT ID, RELAY_STATE AS STATUS, DATE_TOGGLED AS DAY_DISCONNECTED FROM RELAY WHERE ID = :id LIMIT 1";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bindParam(':id', $id, PDO::PARAM_INT);


if ($check_stmt->execute()) {

    $result = $check_stmt->fetch(PDO::FETCH_ASSOC);

    if ($result !== false) {
        echo json_encode($result);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Record not found'], JSON_NUMERIC_CHECK);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database query error'], JSON_NUMERIC_CHECK);
}
?>
