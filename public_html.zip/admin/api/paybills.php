<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

session_start();

require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

// 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $consumerId = $_POST['CONSUMER_ID'];
    $amount = $_POST['AMOUNT'];

    $insertQuery = "INSERT INTO BILLS (CONSUMER_ID, PAID, AMOUNT, DATE_PAID) VALUES (:consumerId, 1, :amount, NOW())";

    try {

        $stmt = $conn->prepare($insertQuery);

        // Bind the values to the placeholders
        $stmt->bindParam(':consumerId', $consumerId, PDO::PARAM_INT);
        $stmt->bindParam(':amount', $amount, PDO::PARAM_INT);

        $stmt->execute();
    
        // Respond with a success message
        $response = ['message' => 'Payment successful'];
        echo json_encode($response);
    } catch (PDOException $e) {
        // Handle database errors here (e.g., log the error)
        error_log('Database error: ' . $e->getMessage());
        http_response_code(500); // Internal Server Error
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    // Invalid request method
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Method Not Allowed']);
}


