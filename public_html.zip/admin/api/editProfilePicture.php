<?php

// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

session_start();

require_once(dirname(__DIR__) . '/db/db.php');
global $db;

$userid = $_SESSION["admin_id"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_FILES['profileImage'])) {
       
        $atts = 'Updated';
        $targetDir = dirname(__DIR__) . "/uploads/";
        $profileImage = $_FILES['profileImage']['name'];
        $targetFile = $targetDir . $profileImage;

        if (move_uploaded_file($_FILES['profileImage']['tmp_name'], $targetFile)) {
            try {

                $query = "UPDATE META SET VALUE = :profile_image, ATTS = :atts WHERE USER_ID = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':profile_image', $profileImage);
                $stmt->bindParam(':atts', $atts);
                $stmt->bindParam(':user_id', $userid);
    
                if ($stmt->execute()) {
                    $response = array(
                        'status' => 'success',
                        'message' => 'Profile image updated successfully.'
                    );
                    echo json_encode($response);
                } else {
                    $response = array(
                        'status' => 'error',
                        'message' => 'Error updating profile image in the database.'
                    );
                    echo json_encode($response);
                }

            } catch(PDOException $e) {
                $db->rollBack();
                echo "Database Error: " . $e->getMessage();
            }
           
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'Error moving the uploaded file.'
            );
            echo json_encode($response);
        }
    } else {
        $response = array(
            'status' => 'error',
            'message' => 'No file input field was found in the request.'
        );
        echo json_encode($response);
    }

} else {
    $response = array(
        'status' => 'error',
        'message' => 'Invalid request method.'
    );
    echo json_encode($response);
}
?>
