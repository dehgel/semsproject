<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Check if the request has the HTTP_X_REQUESTED_WITH header
/**if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
} */
// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connections and global variable $db
require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

// Retrieve data from 'USER', 'BILLS', 'CONFIG' and 'CONSUMED' tables
$query = " SELECT
ID,
CONCAT(FAMILYNAME, ', ', FIRSTNAME, ' ', MIDDLENAME) AS COMNAME,
CASE WHEN ROLE = 1 THEN 'Administrator' ELSE 'Consumer' END AS ROLE,
ADDRESS,
ROUND(COALESCE((SELECT SUM(COALESCE(kWU, 0)) FROM CONSUMED WHERE ID = USER.ID), 0), 2) AS KWh,
COALESCE((SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID), 0) AS PAID,
CASE
    WHEN (ROUND(COALESCE((SELECT SUM(COALESCE(kWU, 0)) FROM CONSUMED WHERE ID = USER.ID), 0), 2) * (SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG)) - COALESCE((SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID), 0)) < 0
    THEN 0
    ELSE ROUND((ROUND(COALESCE((SELECT SUM(COALESCE(kWU, 0)) FROM CONSUMED WHERE ID = USER.ID), 0), 2) * (SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG))) - COALESCE((SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID), 0), 2)
END AS TOPAY,
(SELECT RELAY_STATE FROM RELAY WHERE ID = USER.ID LIMIT 1) AS CONN_STATUS,
ROUND((SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG)), 2) AS RATE
FROM
USER
GROUP BY
ID;
";

$queryResult = $conn->query($query);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($queryResult !== null) {
        echo json_encode($queryResult, JSON_NUMERIC_CHECK);
    } else {
        http_response_code(500); // Internal Server Error
        echo json_encode(['message' => 'Error retrieving data from the database']);
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method Not Allowed']);
}

?>
