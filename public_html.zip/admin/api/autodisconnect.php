<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$relayID = isset($_REQUEST['connstate']) ? $_REQUEST['connstate'] : null;

// Get database connections and global variable $query
require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

// Retrieve the logged-in user's data
$userId = $_SESSION['admin_id'];
$queryResult = $conn->query("SELECT
                                CONSUMER_ID,
                                AMOUNT,
                                MAX(DATE_PAID) AS LPAY,
                                NOW() AS TODAY,
                                DATEDIFF(NOW(), MAX(DATE_PAID)) AS DAYDIFF,
                                CASE WHEN MAX(DATE_PAID) IS NOT NULL THEN   
                                    DATEDIFF(NOW(), MAX(DATE_PAID)) + 1
                                ELSE
                                    0
                                END AS DCONN
                                FROM BILLS
                                GROUP BY CONSUMER_ID;
");

if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'POST') {
    echo json_encode($queryResult[0], JSON_NUMERIC_CHECK);

} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method Not Allowed']);
}
?>
