<?php
/**
 * SEMS server-to-client data transmit
 * @author Deh Saaduddin
 * @version 1.3
 */

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    

    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Start a session
    session_start();
    
    // Get database connections and global variable $query
    require_once(dirname(__DIR__) . '/db/db.php');
    global $db;
    
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] === UPLOAD_ERR_OK) {
        
        $targetDirectory = "../ota/";
        $targetFile = $targetDirectory . basename($_FILES["file"]["name"]);
        
        // Check if the file already exists
        if (file_exists($targetFile)) {
            $response = array(
                "success" => false,
                "message" => "File already exists."
            );
        } else {
            
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
                
               $filename = pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME);
                $version = preg_replace("/[^0-9.]/", "", $filename);
                $fileurl = "https://msusems.net/admin/ota/" . $filename .".bin";

                $jsonContent = array(
                    'ver' => (float)$version,
                    'bin' =>  $fileurl
                );
                
                $jsonString = json_encode($jsonContent, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
                
                $jsonFile = $targetDirectory . 'otadata.json';
                file_put_contents($jsonFile,  $jsonString );
                
                $response = array(
                    "success" => true,
                    "message" => "Upload successful: " . basename($_FILES["file"]["name"])
                );
            } else {
                $response = array(
                    "success" => false,
                    "message" => "Error moving file to destination directory."
                );
            }
        }
    } else {

        $response = array(
            "success" => false,
            "message" => "Error uploading file: " . $_FILES["file"]["error"]
        );
    }

    echo json_encode($response);

} else {
     http_response_code(403);
     echo json_encode(['403'=>'Restricted']);
     exit;
}

?>