<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Content-Type: application/json');

require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

// Default values if not provided in the request
$id = $conn_status = $kwh = $voltage = $current = $powerFactor = null;

// Check the request method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = $_POST['id'];
    $conn_status = $_POST['status'];
    $kwh = $_POST['kwh'];
    $voltage = $_POST['v'];
    $current = $_POST['c'];
    $powerFactor = $_POST['pf'];
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $id = $_GET['id'];
    $conn_status = $_GET['status'];
    $kwh = $_GET['kwh'];
    $voltage = $_GET['v'];
    $current = $_GET['c'];
    $powerFactor = $_GET['pf'];
}


    $sql = "INSERT INTO CONSUMED (ID, CONN_STATUS, kWU, VOLTAGE, CURRENT, PF) VALUES (:id, :conn_status, :kwh, :voltage, :current, :powerFactor)";
    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':conn_status', $conn_status, PDO::PARAM_INT);
    $stmt->bindParam(':kwh', $kwh, PDO::PARAM_INT);
    $stmt->bindParam(':voltage', $voltage, PDO::PARAM_INT);
    $stmt->bindParam(':current', $current, PDO::PARAM_INT);
    $stmt->bindParam(':powerFactor', $powerFactor, PDO::PARAM_STR);

    if ($stmt->execute()) {
        // Retrieve the inserted values
        $insertedValues = [
            'id' => $id,
            'conn_status' => $conn_status,
            'kwh' => $kwh,
            'voltage' => $voltage,
            'current' => $current,
            'powerFactor' => $powerFactor,
        ];

        $response = ['status' => 'success', 'message' => 'OK', 'Vals' => $insertedValues];
        http_response_code(201);
    } else {
        $response = ['status' => 'error', 'message' => 'Error inserting data'];
        http_response_code(500);
    }

?>
