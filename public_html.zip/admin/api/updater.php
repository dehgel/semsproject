<?php

/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connections and global variable $db
require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the request includes data for updating a user
    $data = json_decode(file_get_contents('php://input'), true);

    if( isset($data['user_id']) ) {
        // Extract user data from the request
        $user_id = $data['user_id'];
        $new_username = $data['new_username'];
        $new_role = $data['new_role'];
        $new_email = $data['new_email'];
        $new_firstname = $data['new_firstname'];
        $new_middlename = $data['new_middlename'];
        $new_lastname = $data['new_familyname'];
        $new_address = $data['new_address'];
        // Add more fields as needed

        // Update the user in the database
        $update_query = "UPDATE USER 
                        SET USERNAME = :username, 
                            ROLE = :role,
                            EMAIL = :email, 
                            FIRSTNAME = :firstname,
                            MIDDLENAME = :middlename,
                            FAMILYNAME = :lastname,
                            ADDRESS = :address
                        WHERE ID = :user_id";

        $stmt = $conn->prepare($update_query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':username', $new_username);
        $stmt->bindParam(':role', $new_role);
        $stmt->bindParam(':email', $new_email);
        $stmt->bindParam(':firstname', $new_firstname);
        $stmt->bindParam(':middlename', $new_middlename);
        $stmt->bindParam(':lastname', $new_lastname);
        $stmt->bindParam(':address', $new_address);
        // Bind more parameters for other columns as needed

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'User updated successfully';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error updating user';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Missing user_id ';
    }
 
} else {
    // Handle other HTTP methods (e.g., GET, PUT, DELETE) as needed
    http_response_code(405); // Method Not Allowed
    $response['status'] = 'error';
    $response['message'] = 'Method Not Allowed';
}

// Send the JSON response
echo json_encode($response);
