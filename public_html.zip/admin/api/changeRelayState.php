<?php
/**
 * SEMS server-to-server data exchange
 * Author: Deh Saaduddin
 * Version: 1.0
 */

// Check if the request has the HTTP_X_REQUESTED_WITH header set to XMLHttpRequest
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); 
    echo json_encode(array("message" => "Access denied"));
    exit;
}

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Include the database connection file using PDO
require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $id = intval($_POST['id']);
        
        // Fetch the current relay state
        $sql = "SELECT RELAY_STATE FROM RELAY WHERE ID = ?";
        $stmt = $conn->prepare($sql);
        
        if ($stmt->execute(array($id))) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $currentRelayState = intval($row['RELAY_STATE']);
            
            // Toggle the relay state (1 to 0 and 0 to 1)
            $newRelayState = ($currentRelayState === 1) ? 0 : 1;
            
            // Update the relay state in the database
            $sql = "UPDATE RELAY SET RELAY_STATE = ?, DATE_TOGGLED = NOW() WHERE ID = ?";
            $stmt = $db->prepare($sql);
            
            if ($stmt->execute(array($newRelayState, $id))) {
                $response = array(
                    "message" => "Relay state updated successfully",
                    "new" => $newRelayState,
                    "old" => $currentRelayState
                );
                echo json_encode($response);
            } else {
                http_response_code(500); // Internal Server Error
                echo json_encode(array("message" => "Error updating relay state: " . $stmt->errorInfo()[2]));
            }
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(array("message" => "Error fetching current relay state: " . $stmt->errorInfo()[2]));
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(array("message" => "Database error: " . $e->getMessage()));
    }
} else {
    // Handle non-AJAX requests or unauthorized access
    http_response_code(403); // Forbidden
    echo 'Access Denied';
}
?>
