<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}
// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connections and global variable $query
require_once(dirname(__DIR__) . '/db/db.php');
global $db;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $query = $db->prepate('TRUNCATE CONSUMED');

    if( $query->execute() > 0 ) {
        $query2 = $db->query('TRUNCATE USER');
        $query3 = $db->query('TRUNCATE BILLS');
        $query4 = $db->query('TRUNCATE META');
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method Not Allowed']);
}



