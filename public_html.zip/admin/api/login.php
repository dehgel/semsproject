<?php
// Check if it's an AJAX request
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    // Set the response headers to indicate JSON content
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: POST');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Initialize the response array
    $response = [
        'success' => false,
        'message' => '',
        'role' => ''
    ];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Read and decode JSON data from the request body
        try {
            $data = json_decode(file_get_contents('php://input'));
            
            if ($data) {
                // Include the database connection
                require_once(dirname(__DIR__) . '/db/db.php');
                $conn = new Db();
                $username = trim($data->username);
                $password = md5($data->password);

                // Prepare a query to fetch the user's data based on username and role
                $stmt =  $conn->prepare("SELECT ID, USERNAME, PASSWORD, ROLE FROM USER WHERE USERNAME = (SELECT USERNAME FROM locker_SALT WHERE USERNAME = :username LIMIT 1) AND ROLE = (SELECT ROLE FROM locker_SALT WHERE USERNAME = :username LIMIT 1)");
                $stmt->bindParam(':username', $username, PDO::PARAM_STR);

                if ($stmt->execute()) {
                    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($userData) {
                        if ($password === $userData['PASSWORD']) {
                            session_start();
                            $_SESSION['admin_id'] = $userData['ID'];
                            $_SESSION['esp_id'] = $userData['ID'];
                            $_SESSION['role'] = $userData['ROLE'];
                            $response['success'] = true;
                        } else {
                            $response['message'] = 'Invalid password! Please try again.';
                        }
                    } else {
                        $response['message'] = 'Invalid username or role! Please try again.';
                    }
                } else {
                    throw new Exception('Database error: ' . implode(', ', $stmt->errorInfo()));
                }
            } else {
                throw new Exception('Invalid JSON data!');
            }
        } catch (Exception $e) {
            $response['message'] = 'Error: ' . $e->getMessage();
        }
    }

    // Output the response as JSON
    echo json_encode($response);
} else {
    // Handle non-AJAX requests or unauthorized access
    header('HTTP/1.0 403 Forbidden');
    echo 'Access Denied';
}
?>
