<?php

/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}
// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($_SESSION['admin_id'])) {
        $uid = $_SESSION['admin_id'];
        $miss = $data['mission'];    
        $viss = $data['vision'];      
        $objs = $data['objectives'];   

        $update_query = "UPDATE SITE_OPTIONS SET MISSION = :mission, VISION = :vision, OBJECTIVE = :objectives";

        $stmt = $conn->prepare($update_query);
        $stmt->bindParam(':mission', $miss);
        $stmt->bindParam(':vision', $viss);
        $stmt->bindParam(':objectives', $objs);

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Configuration updated successfully';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error updating configuration';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Missing admin_id';
    }
} else {
    http_response_code(405); // Method Not Allowed
    $response['status'] = 'error';
    $response['message'] = 'Method Not Allowed';
}

echo json_encode($response);
?>
