<?php

/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($_SESSION['admin_id'])) {
        $uid = $_SESSION['admin_id'];
        $ratekwh = $data['ratekwh']; 

        $check_query = "SELECT COUNT(*) FROM CONFIG WHERE USER_ID = :uid";
        $stmt = $conn->prepare($check_query);
        $stmt->bindParam(':uid', $uid);
        $stmt->execute();
        $recordCount = $stmt->fetchColumn();

        if ($recordCount > 0) {
            $update_query = "UPDATE CONFIG SET RATE_KWH = :rate WHERE USER_ID = :uid";
        } else {
            $update_query = "INSERT INTO CONFIG (USER_ID, RATE_KWH) VALUES (:uid, :rate)";
        }

        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':uid', $uid);
        $stmt->bindParam(':rate', $ratekwh);

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Configuration updated successfully';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error updating configuration';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Missing user_id';
    }
} else {
    http_response_code(405); // Method Not Allowed
    $response['status'] = 'error';
    $response['message'] = 'Method Not Allowed';
}

echo json_encode($response);
?>
