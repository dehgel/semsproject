<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}
// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Check if the admin user is logged in
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user_id = isset($data['id']) ? $data['id'] : null;

    if ($user_id !== null) {

        require_once(dirname(__DIR__) . '/db/db.php');
        global $db;

        $delete_query = "DELETE FROM USER WHERE ID = :userId";

        $stmt = $db->prepare($delete_query);
        $stmt->bindParam(':userId', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'User deleted successfully';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error deleting user';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid input data';
    }
} else {
    // Handle other HTTP methods (e.g., GET, PUT, DELETE) as needed
    http_response_code(405); // Method Not Allowed
    $response['status'] = 'error';
    $response['message'] = 'Method Not Allowed';
}

echo json_encode($response);
?>
