<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        
    // Set the response headers to indicate JSON content
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Start a session
    session_start();
    
    // Get database connections and global variable $query
    require_once(dirname(__DIR__) . '/db/db.php');
    $conn = new Db();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Check if the user is logged in (you may need to handle user authentication)
        if (isset($_SESSION['user_id'])) {
            $query = "
                SELECT
                    u.*,
                    m.*
                FROM
                    USER AS u
                LEFT JOIN
                    META AS m
                ON
                    u.ID = m.USER_ID
                WHERE u.ROLE = 1
            ";
    
            $stmt = $conn->prepare($query);
            $stmt->execute();
    
            // Fetch all rows as an associative array
            $userData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            // Check if any records were found
            if ($userData) {
                echo json_encode($userData);
            } else {
                echo json_encode(['message' => 'No user data found for the user.']);
            }
        } else {
            http_response_code(401); // Unauthorized
            echo json_encode(['message' => 'Unauthorized']);
        }
    } else {
        http_response_code(405); // Method Not Allowed
        echo json_encode(['message' => 'Method Not Allowed']);
    }
} else {
    http_response_code(403);
    echo json_encode(['message' => '403 Restricted']);
}
?>