<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connection
require_once(dirname(__DIR__) . '/db/db.php');

try {
    // Set PDO to throw exceptions on error
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Check if a user_id parameter is provided in the URL
        if (isset($_GET['user_id'])) {
            $user_id = $_GET['user_id'];

            // Retrieve messages by user_id from the database
            $selectQuery = "SELECT CONTENT FROM MESSAGE WHERE USER_ID = :user_id";
            $stmt = $db->prepare($selectQuery);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Ensure that the content is returned as JSON without decoding
            echo json_encode($messages);
        } else {
            // If user_id is not provided in the URL, return a message indicating the missing parameter
            http_response_code(400); // Bad Request
            echo json_encode(['status' => 'error', 'message' => 'user_id parameter is missing']);
        }
    } else {
        // Handle the case where the request method is not GET
        http_response_code(405); // Method Not Allowed
        echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
    }
} catch (PDOException $e) {
    // Handle database connection error
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database connection error: ' . $e->getMessage()]);
}
