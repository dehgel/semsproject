<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    // Set the response headers to indicate JSON content
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Include the database connection
    require_once(dirname(__DIR__) . '/db/db.php');
    $conn = new Db();
    $salt = $conn->generateSalt();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // You can capture the content generated so far
        $buff = ob_get_contents();

        //$data = json_decode(file_get_contents('php://input'), true);

        try {
            // Get form data
            $uid            = $_POST["randid"];
            $username       = $_POST["username"];
            $passw          = md5($_POST["passw"]);
            $email          = $_POST["email"];
            $firstname      = $_POST["firstname"];
            $middlename     = $_POST["middlename"];
            $lastname       = $_POST["lastname"];
            $privileges     = $_POST["privileges"];
            $address        = $_POST["address"];
            $course         = isset($_POST["course"]) ? $_POST["course"] : null;
            $mobile         = isset($_POST["mobile"]) ? $_POST["mobile"] : null;
            $socialNetwork  = isset($_POST["socialNetwork"]) ? $_POST["socialNetwork"] : null;
            $buff = $passw;
            
            // File upload handling
            $targetDir = dirname(__DIR__) . "/uploads/";
            $profileImage = $_FILES["profileImage"]["name"];
            $targetFile = $targetDir . $profileImage;

            // Check if the record already exists in the database
            $checkQuery = "SELECT ID FROM USER WHERE ID = ?";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->execute([$uid]);

            if ($checkStmt->rowCount() > 0) {
                echo json_encode(array('status' => 'error', 'message' => 'Duplicate entry: The specified ID already exists.'));
            } else {
                // Create a prepared statement for USER table
                $userQuery = "INSERT INTO USER (ID, USERNAME, ROLE, EMAIL, PASSWORD, FIRSTNAME, MIDDLENAME, FAMILYNAME, COURSE, MOBILE, SOCNET, ADDRESS) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $userParams = array(
                    $uid,
                    $username,
                    $privileges,
                    $email,
                    $passw,
                    $firstname,
                    $middlename,
                    $lastname,
                    $course,
                    $mobile,
                    $socialNetwork,
                    $address
                );

                // Create a prepared statement for META table
                $metaQuery = "INSERT INTO META (USER_ID, VALUE, ATTS) 
                            VALUES (?, ?, ?)";
                $metaParams = array(
                    $uid,
                    $profileImage,
                    $username,
                );

                // Create a prepared statement for META table
                $relayQuery = "INSERT INTO RELAY (ID, RELAY_STATE, DATE_TOGGLED ) 
                            VALUES (?, ?, NOW())";
                $relayParams = array(
                    $uid,
                    1
                );
                // Create a prepared statement for META table
                $seckeyQuery = "INSERT INTO locker_SALT (ID, USERNAME, SALT, ROLE ) 
                            VALUES (?, ?, ?, ?)";
                $seckeyParams = array(
                    $uid,
                    $passw,
                    $username,
                    $privileges
                );

                // Use the prepare function to create prepared statements
                $userStmt = $conn->prepare($userQuery);
                $metaStmt = $conn->prepare($metaQuery);
                $relayStmt = $conn->prepare($relayQuery);
                $seckeyStmt = $conn->prepare($seckeyQuery);

                // Execute the prepared statement for USER table
                $userStmt->execute($userParams);

                // Check if the file has been uploaded successfully
                if (move_uploaded_file($_FILES["profileImage"]["tmp_name"], $targetFile)) {

                    // Check the result of the USER table insert
                    if ($userStmt->rowCount() > 0) {

                        // If the USER table insert was successful, execute the META table insert
                        $metaStmt->execute($metaParams);
                        $seckeyStmt->execute($seckeyParams);

                        // Check the result of the META table insert
                        if ($metaStmt->rowCount() > 0 ) {
                            $relayStmt->execute($relayParams);
                            // Respond with a success message
                            echo json_encode(array('status' => 'success', 'message' => 'Registration successful', 'secretkey'=> $buff));
                        } else {

                            // If META table insert failed, respond with an error message
                            echo json_encode(array('status' => 'error', 'message' => 'META table insert failed.'));
                        }
                    } else {
                        // If USER table insert failed, respond with an error message
                        echo json_encode(array('status' => 'error', 'message' => 'USER table insert failed.'));
                    }
                } else {
                    echo json_encode(array('status' => 'error', 'message' => 'File upload failed.'));
                }

            }
        } catch (PDOException $e) {
            // Handle other database errors
            echo json_encode(array('status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()));
        }
    }

} else {
    // Handle non-AJAX requests or unauthorized access
    header('HTTP/1.0 403 Forbidden');
    echo 'Access Denied';
}
$conn = null;
?>
