<!DOCTYPE html>
<html>
<?php 
  session_start();

  if( !isset( $_SESSION['admin_id']) ) {
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Smart Energy Metering System | Login</title>

  <!-- Google Font: Source Sans Pro --> 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons --> 
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <style>
  #preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(255, 255, 255, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
  }
  
  .spinner {
    width: 40px;
    height: 40px;
    position: relative;
    margin: 100px auto;
  }
  
  .double-bounce1, .double-bounce2 {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: #333;
    opacity: 0.6;
    position: absolute;
    top: 0;
    left: 0;
    animation: sk-bounce 2s infinite ease-in-out;
  }
  
  .double-bounce2 {
    animation-delay: -1s;
  }
  
  @keyframes sk-bounce {
    0%, 100% {
      transform: scale(0);
    } 50% {
      transform: scale(1);
    }
  }
</style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="#"><b>SEMS</b> Admin Login</a>
  </div>
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg"><p id="login-message" style="color: red; display: none;"> </p></p>
      <!-- Preloader -->
      <div id="preloader" style="display: none;">
        <div id="status">
          <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
          </div>
        </div>
      </div>
      <form id="login-form">
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Username" id="username" name="username" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" class="form-control" placeholder="Password" id="password" name="password" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-8">
              <div class="icheck-primary">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">
                  Remember Me
                </label>
              </div>
            </div>
            <div class="col-4">
              <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </div>
          </div>
        </form>
      <div class="social-auth-links text-center mb-3">
        <!-- Add your social login buttons here -->
      </div>

      <p class="mb-1">
        <a href="#">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="#" class="text-center">Register a new membership</a>
      </p>
    </div>
  </div>
</div>
<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
function validateForm() {
  var username = $('#username').val();
  var password = $('#password').val();

  if (username === '' || password === '') {
    alert('Please enter your username and password.');
    return false;
  }

  return true;
}

function disableSubmitButton() {
  $('#login-submit').prop('disabled', true);
}
 $(document).ready(function() {
  $('#login-form').submit(function(event) {
    event.preventDefault();

    // Validate the form
    if (!validateForm()) {
      return;
    }

    // Disable the submit button
    disableSubmitButton();

    // Show the preloader
    $('#preloader').show();

    var username = $('#username').val();
    var password = $('#password').val();

    var formData = {
      username: username,
      password: password
    };

    var jsonData = JSON.stringify(formData);

    $.ajax({
      type: 'POST',
      url: 'api/login.php',
      data: jsonData,
      dataType: 'json',
      success: function(response) {
        $('#preloader').hide();

        // Enable the submit button
        $('#login-submit').prop('disabled', false);

        if (response.success) {
          window.location.href = 'index.php';
        } else {
          $('#login-message').text(response.message).show();
        }
      },
      error: function(error) {
        $('#preloader').hide();

        $('#login-submit').prop('disabled', false);

        console.error(error); 
      }
    });
  });
});

</script>


</body>
</html>
<?php } else {
 require_once(dirname(__DIR__) . '/admin/dashboard.php'); 
}?>