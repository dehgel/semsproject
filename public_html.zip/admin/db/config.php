<?php 

/**
 * Database Configuration
 */

/**
 * The host where the database server is located.
 * @var string
 */
define('DB_HOST', 'localhost');

/**
 * The name of the database you want to connect to.
 * @var string
 */
define('DB_NAME', 'u363281508_smartmeter');

/**
 * The username for connecting to the database.
 * @var string
 */
define('DB_USER', 'u363281508_smartmeter');

/**
 * The password for the database user.
 * @var string
 */
define('DB_PASS', '#Password23*');

/**
 * The port for the database connection (leave empty for the default port).
 * @var string
 */
define('DB_PORT', '');
