<?php

/**
 * Single lining of MySQL query and DB connection for callbacks
 * 
 * @package SEMS
 * @author Deh Saaduddin
 * @version 1.0
 */

require_once( 'config.php' );

class Db {
    // Class internal variables
    protected $host;
    protected $user;
    protected $pass;
    protected $port;
    protected $name;

    protected $conn;

    // Return class as null
    public function __construct() {

        // Database config details
        $this->host = DB_HOST;
        $this->user = DB_USER;
        $this->pass = DB_PASS;
        $this->name = DB_NAME;

        // Initialize the connection
        $this->conn = new PDO("mysql:host={$this->host};dbname={$this->name}", $this->user, $this->pass);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function query(string $query = null, string $single = null) {
        try {
            if ($this->conn === null) {
                // Re-establish the database connection if it's not already open
                $this->conn = new PDO("mysql:host={$this->host};dbname={$this->name}", $this->user, $this->pass);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }

            if ($single === 'single') {
                // Execute the query and fetch a single row as an associative array
                $stmt = $this->conn->query($query);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                // Execute the query and fetch all rows as an associative array
                $result = $this->conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
            }
            return $result;
        } catch (PDOException $e) {
            // Handle any database-related exceptions
            echo json_encode(array('error' => 'Database Error: ' . $e->getMessage()));
            return null;
        }
    }

    // Modify the prepare function to accept parameters
    public function prepare(string $sql, array $params = null) {
        try {
            // Check if the connection is null
            if ($this->conn == null) {
                $this->conn = new PDO("mysql:host={$this->host};dbname={$this->name}", $this->user, $this->pass);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }

            // Prepare the SQL statement
            $stmt = $this->conn->prepare($sql);

            // Bind parameters if provided
            if ($params !== null) {
                foreach ($params as $paramName => $paramValue) {
                    // Determine the data type of the parameter and bind it accordingly
                    $paramType = PDO::PARAM_STR; // Default data type is string
                    if (is_int($paramValue)) {
                        $paramType = PDO::PARAM_INT;
                    } elseif (is_bool($paramValue)) {
                        $paramType = PDO::PARAM_BOOL;
                    }

                    // Bind the parameter with the specified data type
                    $stmt->bindParam($paramName, $paramValue, $paramType);
                }
            }

            return $stmt;
        } catch (PDOException $e) {
            echo json_encode(array('error' => 'Database Error: ' . $e->getMessage()));
            return null;
        }

        $this->conn = null;
    }
    // Convert the MAC to IP address
    public function generateSalt() {
        $length = 32;
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $salt = '';
        for ($i = 0; $i < $length; $i++) {
          $salt .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $salt;
    }
    // Get ESP IP
    public function getPIP() {
        $ip = '';
        
        // Try to get the IP address from the server environment variables
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        // Validate and return the IP address
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        } else {
            return 'Unable to retrieve public IP address';
        }
    }
    
}

// Global variable
$db = new Db();
$espIP = $db->getPIP();

?>
