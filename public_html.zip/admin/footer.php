  <!-- Main Footer -->

  <style>
  input[type=checkbox], input[type=radio] {
    display:contents;
  }
  /* Style for the selected "Connected" button */
  .btn-outline-success.active {
      background-color: #28a745;
      border-color: #28a745;
      color: white;
  }

  /* Style for the selected "Disconnected" button */
  .btn-outline-danger.active {
      background-color: #dc3545;
      border-color: #dc3545;
      color: white;
  }
  label:not(.form-check-label):not(.custom-file-label) {
    font-weight: 700;
    display: flex;
    margin: 0;
    padding: 12px 5;
}
</style>
  <footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="https://msu-main.edu.ph">msu-main.edu.ph</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>
</div>

<!-- Sweet Alert 2 -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<script src="plugins/sweetalert2/sweetalert2.all.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="dist/js/adminlte.js"></script>

<!-- DataTable JS -->
<script type="text/javascript" charset="utf8" src="plugins/datatables/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf8" src="plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script type="text/javascript" charset="utf8" src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Include DataTables Buttons CSS and JS -->
<link rel="stylesheet" type="text/css" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<script type="text/javascript" charset="utf8" src="plugins/datatables-buttons/js/dataTables.buttons.js"></script>
<script type="text/javascript" charset="utf8" src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->



<script>

$(document).ready(function(){
    $('#payBillsModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var id = button.data('id'); 
        var modal = $(this);
        modal.find('.modal-title').text("Payment of ID: " + id);
        modal.find('#consumerIdInput').val(id);
    });

    $('.paybillsBtn').on('click', function() {
        var id = $(this).data('id'); 
        $('#consumerIdInput').val(id);
        $('#payBillsModal').modal('show');
        $('.modal-title').text("Pay Bills for ID: " + id);
    });
    


});
</script>


<script>

$(document).ready(function() {
    
       
    
     var consumersTable = $('#consumersTable').DataTable({
       
        columns: [
        { data: 'ID', name: 'ID'},
        { data: 'NAME' },
        { data: 'KWH USED' },
        { data: 'BALANCE' },
        { data: 'ADDRESS' },
        {
            data: null,
            render: function(data, type, row) {
            return '' + 
            '<div class="btn-group">' +
              '<div class="dropdown">' +
              ' <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actions</button>' +
              '<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">' +
              '<button class="toggle-btn btn btn-outline-primary dropdown-item onoffbtn" style="width:100%;" data-id="' + row.ID + '" data-status="" data-on="1" data-off="0">Switch On/OFF</button>' +
              '<button type="button" data-toggle="modal" data-target="#payBillsModal" class="btn btn-primary dropdown-item paybillsBtn" data-id="' + row.ID + '" data-toggle="modal" style="width:100%;" data-target="#payBillsModal">Pay bills</button>' +
              '<button class="dropdown-item updateBtns" href="#" data-id="' + row.ID + '" style="width:100%;" data-toggle="modal" data-target="#editModal">Edit</button>' +
              '<button type="submit" class="dropdown-item deleteBtn" href="#" data-id="' + row.ID + '">Delete</button><a class="dropdown-item seckeybtn" target="_blank" href="includes/sems_token.php?user_id='+row.ID+'" data-id="' + row.ID + '">Secret Key</a><button id="otaBtn" class="dropdown-item ota_btn" data-id="' + row.ID + '">OTA Update</button>' +
              '</div>' +
              '</div>' + row.IMAGE +
              '</div>';
            }
        },
        { data: 'ROLE'}
        ],
        createdRow: function(row, data, index) {
            var firstColumnTh = $(row).find('td:first');
            firstColumnTh.attr('id', data.ID); 
        },
        columnDefs: [
            {
                targets: -1,
                visible: false
            },
            {
                targets: -1,
                visible: false,
                width: '0px'
            }
        ]
     });
     
    const form = $('#registrationForm');
    const preloader = $('#preloader');
      
      form.submit(function(event) {
          event.preventDefault();
          var formData = new FormData(this);
      
          preloader.removeClass('d-none');
      
          $.ajax({
              type: "POST",
              url: "api/register.php",
              data: formData,
              processData: false, 
              contentType: false, 
              dataType: "json",
              success: function(response) {
                  if (response.status === 'success') {
                      Swal.fire({
                          icon: 'success',
                          title: 'Registration Successful',
                          text: "Copy Secret Key:\n"+response.secretkey+"",
                          confirmButtonText: 'OK',
                      }).then((result) => {
                          if (result.isConfirmed) {
                            $('#registrationForm').modal('hide');
                          }
                      });

                  } else {
                      Swal.fire({
                          icon: 'error',
                          title: 'Registration Error',
                          text: response.message, 
                          confirmButtonText: 'OK',
                      });
                  }
              },
              error: function(xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Registration Error',
                    text: response.message, 
                    confirmButtonText: 'OK',
                });
              },
              complete: function() {
      
                  preloader.addClass('d-none');
              }
          });
      });

     // Add a click event handler to the Delete buttons
     $('#consumersTable tbody').on('click', '.deleteBtn', function () {
            var row = consumersTable.row($(this).closest('tr'));
            var user_id = $(this).data('id');
        
            $.ajax({
                url: 'api/deleteConsumer.php',
                type: 'POST',
                data: JSON.stringify({ id: user_id }), 
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'User deleted Successfully',
                            text: response.message,
                            confirmButtonText: 'OK',
                        });
        
                        // Remove the row from the table
                        row.remove().draw();
                    } else {
                        console.log('Error occurred during deleting user: ' + response.message);
                    }
                },
                error: function (xhr, status, error) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Something went wrong',
                        text: xhr.responseText, 
                        confirmButtonText: 'OK',
                    });
                },
            });
        });



    // Handle user role dropdown change
    $('#userRole').on('change', function () {
      
        const selectedRole = $(this).val();
        consumersTable.search('').draw();
        if (selectedRole !== 'all') {
            consumersTable.columns(6).search(selectedRole).draw();
        }
    });
      

    $('#submitPayment').on('click', function() {

      const consumerId = $('#consumerIdInput').val();
      const amount = $('#amountInput').val();
      const formData = new FormData();
      formData.append('CONSUMER_ID', consumerId);
      formData.append('AMOUNT', amount);

      $.ajax({
          url: 'api/paybills.php', 
          method: 'POST', 
          data: formData, 
          processData: false,
          contentType: false, 
          success: function(response) {

            Swal.fire({
                  icon: 'success',
                  title: 'Payment Successful',
                  text: 'Your payment has been processed successfully.',
                  confirmButtonText: 'OK',
              });

              $('#payBillsModal').modal('hide');
          },
          error: function(error) {
              console.error('Error sending payment:', error);
          }
      });
    });

    // Edit Form on submit
    $('#editFormSubmit').on('click', function() { 
        var id = $("input[name='user_id']").val();
        var newUsername = $("#editUsername").val();
        var newRole = $("#editRole").val();
        var newEmail = $("#editEmail").val();
        var newFirstName = $("#editFirstName").val();
        var newMiddleName = $("#editMiddleName").val();
        var newFamilyName = $("#editFamilyName").val();
        var newAddress = $("#editAddress").val();

        var userData = {
            user_id: id,
            new_username: newUsername,
            new_role: newRole,
            new_email: newEmail,
            new_firstname: newFirstName,
            new_middlename: newMiddleName,
            new_familyname: newFamilyName,
            new_address: newAddress
        };

        // Perform the AJAX request
        $.ajax({
            url: 'api/updater.php', 
            type: 'POST',
            dataType: 'json',
            data: JSON.stringify(userData),
            contentType: 'application/json',
            success: function (response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Updated Successful',
                        text: response.message,
                        confirmButtonText: 'OK',
                    });
       
                    $('#editModal').hide();

                } else {
                    alert('Error updating user: ' + response.message);
                }
            },
            error: function (error) {
                console.error('Error updating user:', error);
            }
        });
        });
        
        let currentStatus = 1; 
       // Function to handle button click event
        $('#consumersTable tbody').on('click', '.toggle-btn', function () {
            const id = parseInt($(this).data("id"));
            const onValue = $(this).data("on");
            const offValue = $(this).data("off");
        
            const newStatus = (currentStatus === 1) ? 1 : 0; 
        
            // Send the new status value to the server
            $.ajax({
                type: "POST",
                url: "api/changeRelayState.php",
                dataType: 'json',
                data: {
                    id: id,
                    status: newStatus,
                    onValue: onValue,
                    offValue: offValue
                },
                success: function (response) {
                    // Update the UI here if needed
                    console.log(response);
                },
                error: function (xhr, status, error) {
                    console.error(error);
                }
            });
        
            // Update the UI based on the newStatus value
            const newText = (newStatus === 1) ? 'connected' : 'disconnected';
            updateUI(newText);
        
            // Update the currentStatus for the next click
            currentStatus = newStatus;
        });
        
        // Function to update the UI based on the new relay state
        function updateUI(newText) {
            let countdown = 5;
        
            Swal.fire({
                icon: 'success',
                title: 'Request approved!',
                text: `Consumer has been ${newText}`,
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false,
                onBeforeOpen: () => {
                    Swal.getContent().querySelector('strong').textContent = countdown;
                    countdown--;
        
                    // Update the countdown every second
                    const interval = setInterval(() => {
                        if (countdown >= 0) {
                            Swal.getContent().querySelector('strong').textContent = countdown;
                            if (countdown === 1) {
                                Swal.getContent().querySelector('p').textContent = `Consumer ${newText}`;
                            }
                            countdown--;
                        } else {
                            clearInterval(interval);
                        }
                    }, 1000);
                }
            });
        }


        
       // Fetch data from your PHP API
        $.ajax({
            url: 'api/consumerslist.php',
            method: 'GET',
            dataType: 'json',
            success: function (data) {
                $.each(data, function (index, consumer) {
                    var connStatus = consumer.CONN_STATUS; 
                    var imageFile = connStatus === 1 ? 'green.png' : 'red.png';
        
                    consumersTable.row.add({
                        'ID': consumer.ID,
                        'NAME': consumer.COMNAME,
                        'KWH USED': consumer.KWh + " KWH",
                        'BALANCE': "₱ " + consumer.TOPAY,
                        'ADDRESS': consumer.ADDRESS,
                        'STATUS': '',
                        'ROLE': consumer.ROLE,
                        'IMAGE': '<img src="dist/img/' + imageFile + '" alt="Status Image" style="width:20px;height:20px;margin: 8%;">'
                    }).draw(false);
                });
            },
            error: function (error) {
                console.error('Error fetching data:', error);
            }
        });
        
        

});
</script>


<?php require_once('footer-scripts.php');?>

<!-- Your custom script -->
<script type="text/javascript" src="dist/js/pages/script.js"></script>
</body>
</html>