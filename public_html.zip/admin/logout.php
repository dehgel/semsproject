<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
// Check if the request has the HTTP_X_REQUESTED_WITH header
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403); // Forbidden
    echo json_encode(array("message" => "Access denied"));
    exit;
}
// Start a session if not already started
session_start();

// Perform any logout-related tasks, e.g., destroying the session
session_destroy();

// Respond with a success message
echo json_encode(['message' => 'Logout successful']);
?>