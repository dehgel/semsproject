<?php
require_once(dirname(__FILE__) . '/api/session.php');
global $db;
$user_id = $_SESSION['admin_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Smart Energy Metering System | Dashboard</title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">

   <!-- Sweet Alert 2-->
   <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.css">
   <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <!-- Include DataTables.js -->
  <link rel="stylesheet" type="text/css" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <link rel="stylesheet" type="text/css" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">

  <style>
    /* Style the modal */
  .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.4);
  }
  #editSettingsForm {display:none;}
  /* Style the modal content */
  .modal-content {
      background-color: white;
      margin: 15% auto;
      padding: 20px;
      border: 1px solid #888;
      width: auto;
  }

  /* Style the close button */
  .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
  }

  .close:hover,
  .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
  }
  .modal-backdrop {
    display:none;
  }
  .hidden {
    display:none;
  }
  #consumersTable {
    width:100%!important;
  }
  .modal-popup {
    display:none;
    background: #000000a1;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 999999;
    scroll-behavior: auto;
    overflow-y: auto;
  }
  .modal-popup::-webkit-scrollbar {
    width: 0;
  height: 0;
  }
  .info {display:flex!important;width:100%;}
  .info #adminusername {padding: 0px 60% 0 0px;}
  .info #editIcon {color:#007bff;}
  /* Image */
#modalImage {
  max-width: 100%;
  max-height: 300px;
  display: block;
  margin: 0 auto 20px;
}

/* File Input and Update Button */
#fileInput {
  display: block;
  margin: 0 auto;
  margin-top: 10px;
}

#updateButton {
  display: block;
  margin: 0 auto;
  margin-top: 10px;
}
#editProfilePic .modal-content {
  width: 35%!important;
}
#existprofpics {
  cursor: pointer;
}
/* Hide the dropdown menu by default */
#actionBtns {
    display: none;
}

/* Show the dropdown menu when hovering over the dropdown button */
.dropdown-toggle:hover #actionBtns {
    display: block;
}
</style>
<!-- Include jQuery library -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Bootstrap 5.5.0 CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- Include Bootstrap 5.5.0 JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

<script>
  var $ = jQuery.noConflict();
</script>
</head>
<!-- Start body -->
<body class="hold-transition sidebar-mini">
<!-- Edit attachment Modal -->

<div id="editProfilePic" class="modal">
<div class="modal-content">
  <span class="close">×</span>
  
  <img id="existprofpics" src="/admin/uploads/Electrical-Logo.png" alt="Profile Image">
  <form id="updateForm" enctype="multipart/form-data">
    <input type="text" id="profileid" value="<?php echo $user_id; ?>" hidden>
    <input type="file" id="fileInput" name="profileImage">
    <button type="button" class="btn btn-secondary modal-close  " id="close">Close</button>
  </form>

</div>
</div>
 <!-- Edit Settings -->
 <div id="editSettings" class="modal fade show" tabindex="-1" role="dialog" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <ul class="nav nav-tabs" id="settingsTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="general-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General Settings</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="other-tab" data-bs-toggle="tab" href="#other" role="tab" aria-controls="other" aria-selected="false">KWH Rate Settings</a>
                    </li>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="tab-content" id="settingsTabsContent">
                    <!-- General Settings Tab -->
                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                    <form id="editAboutSettings">
                    <div class="mb-3">
                        <label for="objectives" class="form-label">Objectives</label>
                        <textarea class="form-control" id="objectives" name="objectives" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="mission" class="form-label">Mission</label>
                        <textarea class="form-control" id="mission" name="mission" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="vision" class="form-label">Vision</label>
                        <textarea class="form-control" id="vision" name="vision" rows="4"></textarea>
                    </div>
                    <div class="modal-footer">
                <button type="button" id="AboutCloaseBtn" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" id="AboutSaveBtn" class="btn btn-primary" id="submitSettings">Save Changes</button>
            </div>
                  </form>
                    </div>

                    <!-- Other Settings Tab -->
                    <div class="tab-pane fade" id="other" role="tabpanel" aria-labelledby="other-tab">
                        
                        <form id="editSettingsForm">
                            <div class="mb-3">
                                <label for="ratekwh" class="form-label">Update Rate/KWH</label>
                                <input type="text" class="form-control" id="ratekwh" name="ratekwh" required="">
                            </div>
                            <div class="mb-3">
                                <button type="button" id="rateClosebtn" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="rateSavebtn" class="btn btn-primary" id="submitSettings">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
       
        </div>
    </div>
</div>


<!-- /. Edit Settings -->