<?php

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connections and global variable $db
require_once(dirname(__DIR__) . '/db/db.php');
$conn = new Db();

// Check if user_id is provided in the GET request
if (isset($_GET['user_id'])) {
    // Sanitize and validate the user_id
    $user_id = filter_var($_GET['user_id'], FILTER_VALIDATE_INT);

    if ($user_id !== false) {
        // Prepare and execute the SQL query
        $stmt = $conn->prepare("SELECT SALT FROM locker_SALT WHERE ID = :user_id");
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            // Fetch the result
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                
                $seckey = $result['SALT'];
                
                // Return the SALT as JSON
                $secretykey = json_encode($seckey, JSON_UNESCAPED_SLASHES);
                echo $secretykey;
            } else {
                http_response_code(404); // Not Found
                echo json_encode(array("message" => "User ID not found"));
            }
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(array("message" => "Database error"));
        }
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(array("message" => "Invalid user ID"));
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(array("message" => "User ID not provided"));
}
?>
