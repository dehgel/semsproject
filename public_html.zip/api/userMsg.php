<?php
// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session (only if you need sessions for authentication)
// session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
    // Get database connections and global variable $db
    require_once(dirname(__DIR__) . '/admin/db/db.php');
    global $db;
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    $content = [
        "message" => "Hello world",
        "ip" => $ip,
        "user_agent" => $user_agent
    ];
    
    // Insert data into the database using prepared statements
    $sql = "INSERT INTO MESSAGE (USER_ID, BODY_MSG) VALUES (?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("is", $user_id, json_encode($content));
    
    if ($stmt->execute()) {
        echo json_encode(["message" => "Data inserted successfully"]);
    } else {
        http_response_code(500); // Internal Server Error
        echo json_encode(["error" => "Database error"]);
        error_log("Database error: " . $stmt->error);
    }
}
?>
