<?php

// Check if the request is made via AJAX
/**$isAjaxRequest = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if (!$isAjaxRequest) {
    http_response_code(403); // Forbidden
    echo json_encode(['message' => 'Direct access not allowed']);
    exit;
}**/

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Check if the admin user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['message' => 'Unauthorized']);
    exit;
}

// Get database connections and global variable $query
require_once(dirname(__DIR__) . '/admin/db/db.php');
$conn = new Db();

// Retrieve the logged-in user's data
$userId = $_SESSION['user_id'];
$queryResult = $conn->query("SELECT
                ID,
                (SELECT MAX(PAID) FROM BILLS WHERE CONSUMER_ID = USER.ID) AS PAID,
                (SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID) AS AMT,
                (SELECT SUM(VOLTAGE) / COUNT(VOLTAGE) FROM CONSUMED WHERE ID = USER.ID) AS VOLT_AVG,
                (SELECT SUM(CURRENT) FROM CONSUMED WHERE ID = USER.ID) AS CURR,
                (SELECT SUM(PF) FROM CONSUMED WHERE ID = USER.ID) AS TO_PF,
                (SELECT ROUND(SUM(kWU), 2) FROM CONSUMED WHERE ID = USER.ID) AS KWUSED,
                (
        SELECT CASE
            WHEN (
                (SELECT ROUND(SUM(kWU), 2) FROM CONSUMED WHERE ID = USER.ID) * (SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG))
            ) = ABS((SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID))
            THEN 0
            ELSE (
                (SELECT ROUND(SUM(kWU), 2) FROM CONSUMED WHERE ID = USER.ID) * (SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG))
            ) - ABS((SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID))
        END
    ) AS CREDITS,
                USERNAME,
                EMAIL,
                FIRSTNAME,
                MIDDLENAME,
                FAMILYNAME,
                ADDRESS,
                (
                    SELECT CONCAT(
                        DAYNAME(MAX(DATE_PAID)), ' ',
                        MONTHNAME(MAX(DATE_PAID)), ' ',
                        DAYOFMONTH(MAX(DATE_PAID)), ', ',
                        YEAR(MAX(DATE_PAID))
                    )
                    FROM BILLS WHERE CONSUMER_ID = USER.ID
                ) AS LAST_PAID,
                ABS( (SELECT SUM(AMOUNT) FROM BILLS WHERE CONSUMER_ID = USER.ID) - (SELECT ROUND( SUM(kWU), 2) FROM CONSUMED WHERE ID=USER.ID) * (SELECT RATE_KWH FROM CONFIG WHERE DATE_RATED = (SELECT MAX(DATE_RATED) FROM CONFIG) ) ) AS TOPAY
                FROM USER WHERE ID={$userId} AND ROLE = 2", 'single');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($queryResult) {
        // Encode the single row of data into JSON
        echo json_encode($queryResult);
    } else {
        // Handle the case where the query fails
        http_response_code(500); // Internal Server Error
        echo json_encode(['message' => 'Internal Server Error']);
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method Not Allowed']);
}

?>
