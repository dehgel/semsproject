<?php
/**
 * SEMS server-to-server data exchange
 * @author Deh Saaduddin
 * @version 1.0
 */
 
// Check if the request is made via AJAX
$isAjaxRequest = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if ($isAjaxRequest) {
    

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

$relayID = $_GET['uid'];
$sessionID = $_SESSION['user_id'];

// Get database connections and global variable $query
require_once(dirname(__DIR__) . '/admin/db/db.php');
global $db;


if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Retrieve the logged-in user's ID
    $userId = $_SESSION['user_id'];

    // Query the CONSUMED table for user data
    $query = "
        SELECT
            *
        FROM
            SITE_OPTIONS
    ";

    $stmt = $db->prepare($query);
    //$stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();
    
    // Fetch all rows as an associative array
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if any records were found
    if ($userData) {
        echo json_encode($userData);
    } else {
        echo json_encode(['message' => 'No user data found for the user.']);
    }

} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method Not Allowed']);
}

} else {
    http_response_code(403); // Forbidden
    echo json_encode(['message' => 'Direct access not allowed']);
    exit;
}

?>