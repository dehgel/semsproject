<?php

// Check if the request is made via AJAX
$isAjaxRequest = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if (!$isAjaxRequest) {
    http_response_code(403); // Forbidden
    echo json_encode(['message' => 'Direct access not allowed']);
    exit;
}

// Start a session if not already started
session_start();

// Perform any logout-related tasks, e.g., destroying the session
session_destroy();

// Respond with a success message
echo json_encode(['message' => 'Logout successful']);
?>