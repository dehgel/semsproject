<?php
/** 
 * ESP Validator
 * Confirming ID and Secret key sent by ESP32.
 * 
 * @author Deh Saaduddin
 * 
 * @version 1.0
 * 
 */

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');

$seckey = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['seckey'])) {
    $seckey = $_GET['seckey'];
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seckey'])) {
    $seckey = $_POST['seckey'];
}

try {
    require_once(dirname(__DIR__) . '/admin/db/db.php');
    $conn = new Db();

    // Validate the ID and PASSWORD against the database
    $sqlquery = "SELECT ID, SALT FROM locker_SALT WHERE ID = ?";
    $stmt = $conn->prepare($sqlquery);

    // Split the seckey and use the first part
    $uid = explode('$', $seckey);
    
    if (count($uid) > 0) {
        
        $stmt->execute([$uid[0]]);
        $row = $stmt->fetch();

        if ($row) {
            
            $seckeyQuery = $row['ID'] .'$'. $row['SALT'];

            // Check if the hashed input password matches the stored password
            if ($seckey === $seckeyQuery) {
                
                session_start();
                ob_start();
                
                $_SESSION['esp_id'] = $row['ID'];

                // Respond with a success message as JSON
                $response = array(
                    "status" => "Session created"
                );
                http_response_code(200);
                echo json_encode($response);
            } else {
                // Authentication failed as JSON
                $response = array(
                    "status" => "Authentication failed"
                );
                http_response_code(401);
                echo json_encode('401');
            }
        } else {
            // User not found as JSON
            $response = array(
                "status" => "User not found"
            );
            http_response_code(404);
            echo json_encode('404');
        }
    } else {
        // Handle the case where the seckey is not split correctly
        // Respond with an error message as JSON
        http_response_code(400); // Bad Request
        echo json_encode(array("status" => "400"));
    }
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage(), 0);
}


?>
