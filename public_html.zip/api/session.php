<?php

session_start();

if ( !isset($_SESSION['user_id']) || !isset($_SESSION['esp_id']) ) {
    header("Location: index.php"); 
    exit();
}