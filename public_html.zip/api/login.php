<?php

/**
 * Login authentication
 * 
 * @author Deh Saaduddin
 * 
 */

// Check if the request is made via AJAX
$isAjaxRequest = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if (!$isAjaxRequest) {
    http_response_code(403); // Forbidden
    echo json_encode(['message' => 'Direct access not allowed']);
    exit;
}

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$response = [
    'success' => false,
    'message' => '',
    'role' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Include the database connection
    require_once(dirname(__DIR__) . '/admin/db/db.php');
    $conn = new Db();
    
    $user = trim($_POST['username']);
    $userData = $conn->query("SELECT * FROM USER WHERE USERNAME='{$user}' AND ROLE = '2'");

    // Simulate a simple authentication process
    $userid = $userData[0]['ID'];
    $validUsername = $userData[0]['USERNAME'];
    $validPassword = $userData[0]['PASSWORD'];
    $role = $userData[0]['ROLE'];

    $submittedUsername = $_POST['username'];
    $submittedPassword = md5($_POST['password']); // Hash the password using MD5

    if ($submittedUsername === $validUsername && $submittedPassword === $validPassword) {
        
        session_start();
        ob_start();
        $_SESSION['user_id'] =  $userid;
        $_SESSION['esp_id'] = $userid;
        $_SESSION['role'] = $role;
        // Valid credentials
        $response['success'] = true;
        
    } else {
        // Invalid credentials
        $response['message'] = 'Invalid credentials: ' . $submittedUsername . ' / ' . $submittedPassword;
    }
}


// Output the response as JSON
echo json_encode($response);
?>
