<?php

// Check if the request is made via AJAX
$isAjaxRequest = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if (!$isAjaxRequest) {
    http_response_code(403); // Forbidden
    echo json_encode(['message' => 'Direct access not allowed']);
    exit;
}

// Set the response headers to indicate JSON content
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Start a session
session_start();

// Get database connections and global variable $query
require_once(dirname(__DIR__) . '/admin/db/db.php');
global $db;

// Retrieve the logged-in user's data
$userId = $_SESSION['user_id'];

// Simulated data retrieval from the database
$consumesData = $db->query("SELECT DATE, ROUND(VOLTAGE,2) AS VOLTAGE, ROUND(CURRENT,3) AS CURRENT,ROUND(PF, 2) AS PF, ROUND(kWU,2) AS kWU FROM CONSUMED WHERE ID = {$userId}");

// Organized monthly averages
$monthlyAverages = [
    'DATE' => array_fill(0, 12, 0),
    'VOLTAGE' => array_fill(0, 12, 0),
    'CURRENT' => array_fill(0, 12, 0),
    'PF' => array_fill(0, 12, 0),
    'kWU' => array_fill(0, 12, 0)
];

$monthlyCounts = array_fill(0, 12, 0);

foreach ($consumesData as $consume) {
    $Vs = $consume['VOLTAGE'];
    $month = intval(date('n', strtotime($consume['DATE']))) - 1;
    $monthlyAverages['VOLTAGE'][$month] += $Vs;
    $monthlyCounts[$month]++;
    $monthlyAverages['CURRENT'][$month] += $consume['CURRENT'];
    $monthlyAverages['PF'][$month] += $consume['PF'];
    $monthlyAverages['kWU'][$month] += $consume['kWU'];
}

foreach ($monthlyAverages['VOLTAGE'] as $month => $totalVoltage) {
    if ($monthlyCounts[$month] > 0) {
        $monthlyAverages['VOLTAGE'][$month] /= $monthlyCounts[$month];
    }
}

// Prepared data for chart
$labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$datasets = [];

$colors = ['#007bff', '#dc3545', '#28a745'];

foreach (['VOLTAGE', 'CURRENT', 'PF', 'kWU'] as $index => $dataType) {
    $datasets[] = [
        'type' => 'line',
        'label' => $dataType,
        'data' => $monthlyAverages[$dataType],
        'backgroundColor' => 'transparent',
        'borderColor' => $colors[$index],
        'pointBorderColor' => $colors[$index],
        'pointBackgroundColor' => $colors[$index],
        'fill' => false,
    ];
}

$data = [
    'labels' => $labels,
    'datasets' => $datasets,
];

// Output the JSON response
echo json_encode($data, JSON_NUMERIC_CHECK);
?>